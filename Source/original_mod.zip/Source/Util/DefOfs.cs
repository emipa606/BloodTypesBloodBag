using RimWorld;
using Verse;

namespace BloodTypes
{
    [DefOf]
    public class HediffDefOf
    {
        public static HediffDef BloodType;
    }
    
    [DefOf]
    public class ThingDefOf
    {
        public static ThingDef BloodBag;
        
    }
}